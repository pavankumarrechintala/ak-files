import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaderResponse, HttpHeaders} from '@angular/common/http'
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class MobileserviceService {
   cartapi:string='http://localhost:4501/cart'
  mobileapi:string='http://localhost:4501/mobile';
  userapi="http://localhost:4501/user";
  constructor(private htp:HttpClient,) { }
  addmobile(mobile):Observable<any>{
   var httpoption={
        headers:new HttpHeaders({'Content-Type':'application/json'})
    }
    console.log(JSON.stringify(mobile))
    return this.htp.post(this.mobileapi,JSON.stringify (mobile),httpoption)
  }
  adduser(user){
    const headeropton={
headers:new HttpHeaders({'Content-Type':'application/json'})
    }
    return this.htp.post(this.userapi,user,headeropton)
  }
  getmobile():Observable<any>{
   return this.htp.get(this.mobileapi,{responseType:'json'})
  }
  getmobileid(id){
    return this.htp.get(this.mobileapi+'/'+id,{responseType:'json'})
  }
  addtocart(cart){
    var headerop={
      headers:new HttpHeaders({'Content-Type':'application/json'})
    }
        console.log(JSON.stringify (cart))
    return this.htp.post(this.cartapi,cart,headerop)
  }
  getcart(id){
   return this.htp.get(this.cartapi+'/'+id,{responseType:'json'})
  }
  deletecart(id){
    return this.htp.delete(this.cartapi+'/'+id,{responseType:'json'})
  }
}
