export class register{
    fname:string;
    lname:string;
    mname:string;
    email:string;
    mobile:number;
    passwords:string;
   address:string;
   userimage:any;
}