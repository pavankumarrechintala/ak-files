export class carts{
    userid:number;
    mobileid:number;
    status:string='pending';
    price:number=1200;
}