export class mobile{
mobilename:string;
mobilebrand:string;
modelnumber:number;
RAM:number;
ROM:number;
camera:string;
processor:string;
mobileimage:any;
price:number;
description:string;
rating:number;
releasedate:Date;
status:string;
}