import { Component, OnInit } from '@angular/core';
import {MobileserviceService} from '../sercives/mobileservice.service'
import {vcart} from '../model/viewcart'
@Component({
  selector: 'viewcart',
  templateUrl: './viewcart.component.html',
  styleUrls: ['./viewcart.component.css']
})
export class ViewcartComponent implements OnInit {
  vwcart:any[20];
  constructor(private ms:MobileserviceService) {
    let cart:any[];
  }
 
  ngOnInit() {
    this.ms.getcart(1).subscribe(data=>{
      this.vwcart=data;
      }) 
  }
  
dele(id){
  this.ms.deletecart(id).subscribe(data=>{console.log(data)
  this.ngOnInit();
  })
}
}
