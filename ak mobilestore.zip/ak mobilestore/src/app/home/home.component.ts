import { Component, OnInit } from '@angular/core';
import {mobile,} from '../model/mobiles';
import {carts} from '../model/cart'
import {MobileserviceService} from '../sercives/mobileservice.service'
@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

    mobiles:any[];
    cart:carts;
  constructor(private ms:MobileserviceService) {

    this.cart=new carts();
   }

   addcart(userid,mobileid)
   {
     this.cart.mobileid=mobileid;
     this.cart.userid=userid;
 this.ms.addtocart(this.cart).subscribe(data=>{console.log})
   }

  ngOnInit() {
this.ms.getmobile().subscribe(data=>{
  this.mobiles=data;
})
  }

}
