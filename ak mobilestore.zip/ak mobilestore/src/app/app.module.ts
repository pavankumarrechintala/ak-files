import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import{FormsModule} from '@angular/forms';
import { RegisterComponent } from './register/register.component';
import { AddmobilesComponent } from './addmobiles/addmobiles.component';
import {HttpClientModule} from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { ViewcartComponent } from './viewcart/viewcart.component';
import { ViewmobileComponent } from './viewmobile/viewmobile.component'
@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    AddmobilesComponent,
    HomeComponent,
    ViewcartComponent,
    ViewmobileComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
