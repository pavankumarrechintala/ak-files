import { Component, OnInit } from '@angular/core';
import{mobile} from '../model/mobiles'
import {MobileserviceService} from '../sercives/mobileservice.service'
@Component({
  selector: 'viewmobile',
  templateUrl: './viewmobile.component.html',
  styleUrls: ['./viewmobile.component.css']
})
export class ViewmobileComponent implements OnInit {


  mobiles:mobile;
  constructor(private ms:MobileserviceService) {
  this.mobiles=new mobile();

   }

  ngOnInit() {
   var  mobile:any;
  //will have to use activated routes to get id from home page
  this.ms.getmobileid(7).subscribe(data=>{
     this.mobiles=data[0];
  })
  }

}
