import { Component, OnInit } from '@angular/core';
import {register} from '../model/userregisteration'
import { MobileserviceService } from '../sercives/mobileservice.service';
@Component({
  selector: 'register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  user:register;
  constructor(private ms:MobileserviceService) {
    this.user=new register();MobileserviceService
   }
   valid:string="";
cpw:any;
cpws:boolean=true;
  ngOnInit() {
  }

  submitbtn(frm){
if(this.cpw!=this.user.passwords){
  this.cpws=false;
  this.valid="please enter the valid details"
}
if(this.cpw==this.user.passwords){
  this.cpws=true;
  this.valid=""
}
if(frm.valid && this.cpws==true){
  this.ms.adduser(this.user).subscribe(data=>{console.log(data)})
}
else
{
  this.valid="please enter the valid details"
}
  }

}
