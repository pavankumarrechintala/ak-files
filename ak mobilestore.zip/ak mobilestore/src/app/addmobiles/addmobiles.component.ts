import { Component, OnInit } from '@angular/core';
import{mobile} from '../model/mobiles'
import {MobileserviceService} from '../sercives/mobileservice.service'
@Component({
  selector: 'addmobiles',
  templateUrl: './addmobiles.component.html',
  styleUrls: ['./addmobiles.component.css']
})
export class AddmobilesComponent implements OnInit {
  

  mobiles:mobile;
  constructor(private ms:MobileserviceService) {
    this.mobiles=new mobile();
   }

  ngOnInit() {
  }
url;
  filesys(event){
    if(event.target.files){
     var reader=new FileReader();
     reader.readAsDataURL(event.target.files[0]);
     reader.onload=(ev:any)=>{
     this.url=ev.target.result;
     this.mobiles.mobileimage=reader.result;
     console.log(this.mobiles.mobileimage)
     }
    }
  }

  btn(frm){
    if(frm.valid){
    this.mobiles.mobileimage=this.mobiles.mobileimage.replace("data:image/jpeg;base64,","")
    this.mobiles.mobileimage=this.mobiles.mobileimage.replace("data:image/png;base64,","")
    this.mobiles.mobileimage=this.mobiles.mobileimage.replace("data:image/jpg;base64,","")
    this.ms.addmobile(this.mobiles).subscribe(data=>{console.log(data)})
  }
  else{
    alert(JSON.stringify(this.mobiles))
    alert('enter fields')
  }
  }
  
}
