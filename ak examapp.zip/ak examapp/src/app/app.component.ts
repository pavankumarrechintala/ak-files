import { Component, OnChanges, DoCheck } from '@angular/core';
import {MenuItem} from 'primeng/api'
import { Observable,of } from 'rxjs';
import { viewAttached } from '@angular/core/src/render3/instructions';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements DoCheck {
  items: MenuItem[];
  adl:Observable<any>;

   
  vi=false;  
  constructor(){
   
    this.items=[{label:'take exam',routerLink:'exam',icon:'pi pi-fw pi-plus'},
  {label:'add questions',routerLink:'addquestions',visible:this.vi}]

}
chechad():Observable<any>{
  return of(localStorage.getItem('adm'))
}
ngDoCheck(){
this.chechad().subscribe(data=>{
  this.adl=data;
 
})

}
}
