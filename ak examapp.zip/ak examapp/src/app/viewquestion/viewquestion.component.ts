import { Component, OnInit } from '@angular/core';
import { ExamserviceService } from '../services/examservice.service'
import { anss } from '../model/ans'
import { ans } from '../model/answe';
import {Router} from '@angular/router'
import { MessageService } from 'primeng/api';
import {image} from '../model/img' 

@Component({
  selector: 'viewq',
  templateUrl: './viewquestion.component.html',
  styleUrls: ['./viewquestion.component.css']
})
export class ViewquestionComponent implements OnInit {
im:image;
  //store all questionid 
  prevques: any[] = [];
  ques: any[];

end;
hig="gjg";
hi:any[];
nxt="cff";
  pres = "";
  //to get the number of question for a purticular questionid 
  tlen;
  //display completed test
  com;
  //store selected option of user
  ans;
  //to show score
  count = 0;
  //to enable prev button
  pre;
  techname;
display;
qno=1;

  answ: any[] = [];
  uploadedFiles:any[]=[];;
  constructor(private rt:Router,private exs: ExamserviceService,private msg:MessageService) {
    this.exs.viewtques(localStorage.getItem('tid')).subscribe(data => 
      {
this.im=new image();
      console.log(data)
    
      this.hi=data;})
    this.startTimer()

  }
  timeLeft: number = 60;
  min:number=1;
 interval;
 fli:any;
addt(){
this.display=false;
this.finish();
}
  startTimer() {
    this.interval = setInterval(() => {

      if(this.timeLeft > 0) {
        this.timeLeft--;
      }
       else {
         this.min=this.min-1;
         
        if(this.min<0){
          clearInterval(this.interval);
this.finish()
        }
      else  if(this.min==0 && this.timeLeft==30){
          this.msg.add({severity:'warn',detail:'Only 30 sec left'})
                }
        else{
          this.timeLeft=60;
        
        }
      }
    },1000)
  }
  finish(){
for (let index = 0; index < this.answ.length; index++) {

  if(this.answ[index].selectop===this.answ[index].answer){
    this.count=this.count+1;
  }
  else
  {
    console.log(this.count)
  }


}
localStorage.removeItem('score');
localStorage.removeItem('quesa');
localStorage.setItem('quesa',this.answ.length.toString());
localStorage.setItem('score',this.count.toString())
localStorage.setItem('tq',this.tlen);
localStorage.setItem('m',(this.min.toString()))
localStorage.setItem('sec',this.timeLeft.toString())
this.rt.navigate(['score'])

  }
  prev() {
    console.log(this.qno)
if(this.qno==2){
  console.log("hre")
this.pre="";
}
    this.qno=this.qno-1;
    this.exs.viewques(this.prevques[this.prevques.indexOf(this.ques[0].questionid) - 1]).subscribe(data => {
      this.ques = data
      if (this.answ[this.answ.findIndex(x=>x.questionid==this.ques[0].questionid)].questionid== this.ques[0].questionid) {
       this.ans= this.answ[this.answ.findIndex(x=>x.questionid==this.ques[0].questionid)].selectop;
      console.log('here');          
      }   
    })
   
  }
  tname;

  ngOnInit() {
    this.techname=localStorage.getItem('tnm');
    var ran = Math.floor(Math.random() * 12)
    console.log(ran)
    this.exs.viewtques(localStorage.getItem('tid')).subscribe(data => {

      console.log(data)
    
      this.tlen = data.length;
    })
    this.exs.viewques(ran).subscribe(data => {

      if (data.length == 1) {

        if (data[0].techid != localStorage.getItem('tid')) {
          this.ngOnInit();
        }
        else {
          if(this.tlen-1==this.prevques.length){
this.end="df"
this.nxt="";
          }
          if (this.tlen == this.prevques.length) {
            this.com = "test completed"
         this.display=true;
         this.qno=this.qno-1;
         console.log(this.display)
          }
          else {

            if (this.prevques.find(x => x == ran)) {

              this.ngOnInit();
            }
            else {
              this.prevques.push(ran)
              this.pres = "1";
              this.ques = data
            }
          }
          localStorage.setItem('df', this.prevques.toString())
          console.log(this.prevques + 'prev')
        }
      }
      else {
        this.ngOnInit();
      }
    }
    )
  }
  onUpload(event) {
    for(let file of event.files) {
        this.uploadedFiles.push(file);
        let fr = new FileReader()
        fr.readAsDataURL(this.uploadedFiles[0]); 
        fr.onload=(evnt:any)=>{
          this.im.images=fr.result;
          this.im.images=this.im.images.replace("data:image/jpeg;base64,","")
          this.im.images=this.im.images.replace("data:video/x-ms-wmv;base64,","")
          console.log(this.im.images)
          this.exs.addim(this.im).subscribe(data=>{data})
        }
        }
      
        console.log('here');
        console.log(this.uploadedFiles)
       

    this.msg.add({severity: 'info', summary: 'File Uploaded', detail: ''});
}

  submit() {
    this.pre = "ffg";
    console.log(this.ans +'jj')
    this.qno=this.qno+1;
    console.log(this.hi )
    if (this.tlen > this.qno){
      console.log('answeree'+this.tlen +this.prevques.length)
    if(this.ans==undefined || this.ans==""){
      this.hi[this.qno].questionid="";
      console.log('herebnh')
    }
else if(this.ans!=undefined || this.ans!=""){
      this.hi[this.qno].questionid="gnmhgnhg";
      console.log(ans)
    }
  }
console.log(this.answ[this.answ.findIndex(x=>x.questionid==this.ques[0].questionid)])

//for storing result of public
if(this.answ[this.answ.findIndex(x=>x.questionid==this.ques[0].questionid)]==undefined){
  this.answ.push({ 'questionid': this.ques[0].questionid, 'selectop': this.ans,'answer': this.ques[0].answer });
} 
else{
  if (this.answ[this.answ.findIndex(x=>x.questionid==this.ques[0].questionid)].questionid== this.ques[0].questionid) {
    this.answ[this.answ.findIndex(x=>x.questionid==this.ques[0].questionid)].selectop=this.ans;
             }
             else
             {
               console.log('hec')
             }
}
   
    console.log(this.answ )


    this.ans = "";
    if (this.prevques[this.prevques.indexOf(this.ques[0].questionid) + 1] == undefined) {

      this.ngOnInit();
    }
    else {
      console.log()
      this.exs.viewques(this.prevques[this.prevques.indexOf(this.ques[0].questionid) + 1]).subscribe(data => {
        this.ques = data
        this.ans= this.answ[this.answ.findIndex(x=>x.questionid==this.ques[0].questionid)].selectop;
      })
    }
  }
}