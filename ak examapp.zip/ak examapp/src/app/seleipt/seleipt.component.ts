import { Component, OnInit } from '@angular/core';
import {ExamserviceService} from '../services/examservice.service'
import {technology} from '../model/tech';
import {Router} from '@angular/router'
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { MessageService } from 'primeng/api';
@Component({
  selector: 'sel',
  templateUrl: './seleipt.component.html',
  styleUrls: ['./seleipt.component.css']
})
export class SeleiptComponent implements OnInit {
st=false;
tc="fg";
tech:technology;
ted:any[];
tec;
  constructor(private exs:ExamserviceService,private rt:Router,private ms:MessageService) { 
    this.tech=new technology();
  }
  uploadedFiles: any[] = [];



    onUpload(event) {
        for(let file of event.files) {
            this.uploadedFiles.push(file);
        }

        this.ms.add({severity: 'info', summary: 'File Uploaded', detail: ''});
    }

  ngOnInit() {
this.exs.gettech().subscribe(data=>{console.log(data)

this.ted=data
})
  }
  submit(){
  this.tc="";
    this.st=true
  }
  nav(id){
    console.log(this.tec)
   
if(this.tec!=undefined){
  this.st=false;
 localStorage.setItem('tid',this.tec.techid);
 localStorage.setItem('tnm',this.tec.technology);
 this.rt.navigate(['starttest'])
  }
else{
this.ms.add({severity:'error',detail:'please select a technology',summary:'select technology'})
}
}
  

}
