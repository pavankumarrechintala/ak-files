export class image{
    images:any;
}