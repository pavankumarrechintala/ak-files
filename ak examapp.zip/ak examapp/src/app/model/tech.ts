export class technology{
    technology:string;
}