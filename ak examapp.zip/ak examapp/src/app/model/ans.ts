export class anss{
    selectop;
    questionid;
}