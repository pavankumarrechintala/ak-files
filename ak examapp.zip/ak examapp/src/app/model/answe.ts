export class ans{
    selectop:any;
    questionid:any;
}