import { Component, OnInit, Injectable } from '@angular/core';
import { LocationStrategy } from '@angular/common';
import { CanDeactivate, Router } from '@angular/router';
import { HostListener } from '@angular/compiler/src/core';
import {Location} from "@angular/common";
import { MessageService } from 'primeng/api';
import {ExamserviceService} from '../services/examservice.service'

@Component({
  selector: 'shoscr',
  templateUrl: './showscore.component.html',
  styleUrls: ['./showscore.component.css']
})
export class ShowscoreComponent implements OnInit {
data
private location:Location;
  constructor(private msg:MessageService,private exs:ExamserviceService) {
   
        
        
    
    this.data = {
      labels: ['total question'+':'+localStorage.getItem('tq'),'correct question'+':'+ localStorage.getItem('score'),'question attempted'+':'+ localStorage.getItem('quesa')],
      datasets: [
          {
              data: [localStorage.getItem('tq'), localStorage.getItem('score'),localStorage.getItem('quesa')],
              backgroundColor: [
                  "#FF6384",
                  "#36A2EB",
                  "#FFCE56"
              ],
              hoverBackgroundColor: [
                  "#FF6384",
                  "#36A2EB",
                  "#FFCE56"
              ]
          }]    
      };
}
   
scr;
qua;
tq;
m;
sec;
uploadedFiles:any[]=[];;
onUpload(event) {
    
    for(let file of event.files) {
        this.uploadedFiles.push(file);
    }

    this.msg.add({severity: 'info', summary: 'File Uploaded', detail: ''});
}
  ngOnInit() {
    history.pushState(null, null,'score');
    window.onpopstate = function () {
        history.go(1);
    };
  this.scr=localStorage.getItem('score');
  this.qua=localStorage.getItem('quesa');
  this.tq=localStorage.getItem('tq');
  this.m=( localStorage.getItem('tnm'))
  this.sec=60-parseInt(localStorage.getItem('sec'));
}

}
