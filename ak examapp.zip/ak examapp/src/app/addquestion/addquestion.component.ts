import { Component, OnInit } from '@angular/core';
import {ExamserviceService} from '../services/examservice.service'
import {questions} from '../model/question'
@Component({
  selector: 'addq',
  templateUrl: './addquestion.component.html',
  styleUrls: ['./addquestion.component.css']
})
export class AddquestionComponent implements OnInit {

  constructor(private exs:ExamserviceService) {
    this.ques=new questions();
   }
   timeLeft: number = 10;
   min:number=2;
  interval;

startTimer() {
    this.interval = setInterval(() => {
      if(this.timeLeft > 0) {
        this.timeLeft--;
      }
       else {
         this.min=this.min-1;
         
        if(this.min<0){
alert('2 min')
        }
        else{
          this.timeLeft=10;
        }
      }
    },1000)
  }




ques:questions;
  ngOnInit() {
  }


  submitbtn(myfrm){

    if(myfrm.valid){
   

    this.ques.techid=parseInt( localStorage.getItem('techid'));
  this.exs.addques(this.ques).subscribe(data=>{console.log(data)})
  }
}


}
