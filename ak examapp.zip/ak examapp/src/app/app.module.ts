import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import {HttpClientModule} from '@angular/common/http'
import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms'
import { AddquestionComponent } from './addquestion/addquestion.component';
import { ViewquestionComponent } from './viewquestion/viewquestion.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations'
import {MenuModule} from 'primeng/menu'
import {Routes,RouterModule} from '@angular/router'
import {MenubarModule} from 'primeng/menubar'
import{InputTextModule} from 'primeng/inputtext';
import { AddtechComponent } from './addtech/addtech.component'
import {ButtonModule} from 'primeng/button'
import {DropdownModule} from 'primeng/dropdown'
import {DialogModule} from 'primeng/dialog'
import {ToastModule} from 'primeng/toast'
import {MessageService} from 'primeng/api';
import { TimeComponent } from './time/time.component'
import {RadioButtonModule} from 'primeng/radiobutton';
import { SeleiptComponent } from './seleipt/seleipt.component';
import { ShowscoreComponent } from './showscore/showscore.component';
import {ChartModule} from 'primeng/chart';
import {FileUploadModule} from 'primeng/fileupload'

const rt:Routes=[{path:'exam',component:SeleiptComponent},
{path:'addquestions',component:AddtechComponent},
{path:'starttest',component:ViewquestionComponent},
{path:'score',component:ShowscoreComponent},
{path:'asques',component:AddquestionComponent},
]
@NgModule({
  declarations: [
    AppComponent,
    AddquestionComponent,
    ViewquestionComponent,
    AddtechComponent,
    TimeComponent,
    SeleiptComponent,
    ShowscoreComponent
  ],
  imports: [
    BrowserModule,FileUploadModule,ChartModule,ToastModule,RadioButtonModule,DialogModule,DropdownModule,InputTextModule,ButtonModule,HttpClientModule,BrowserAnimationsModule,RouterModule.forRoot(rt),FormsModule,MenuModule,MenubarModule
  ],
  providers: [MessageService],
  bootstrap: [AppComponent]
})
export class AppModule { }
