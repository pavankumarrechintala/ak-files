import { Component, OnInit } from '@angular/core';
import {ExamserviceService} from '../services/examservice.service';
import {technology} from '../model/tech'
import {Router} from '@angular/router'
import {MessageService} from 'primeng/api'
@Component({
  selector: 'addt',
  templateUrl: './addtech.component.html',
  styleUrls: ['./addtech.component.css']
})
export class AddtechComponent implements OnInit {
tech:technology;
ted:any[];
adt;  
constructor(private rt:Router,private ms:MessageService,private exs:ExamserviceService) {
    this.tech=new technology();
   }

  ngOnInit() {
 this.exs.gettech().subscribe(data=>{this.ted=data;
  localStorage.setItem('adm','cffv')

})
  }

  sub(t){
if(t){
  localStorage.setItem('techid',t.techid)
  this.rt.navigate(['asques'])
}
else{
  this.ms.add({severity:'error',detail:'please select or add technology'})
}
  }
    addt(t){
if(t==""){
  this.adt=false;
  this.ms.add({severity:'error',detail:'please add technology'})
}
else
{
  this.adt=false;
this.tech.technology=t;
console.log(t)
 this.exs.addtech({'technology':t}).subscribe(data=>{console.log(data) 
  this.rt.navigate(['asques'])})  
}
    }
ant(){
this.adt=true;
}
}