import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ViewquestionComponent } from '../viewquestion/viewquestion.component';

@Injectable({
  providedIn: 'root'
})
export class ExamserviceService {

  constructor(private hts:HttpClient) { }
 
quesapi='http://localhost:4501/addques'

viewquesapi="http://localhost:4501/ques"

techapi="http://localhost:4501/tech"

gettech():Observable<any>{
return this.hts.get(this.techapi,{responseType:'json'})
}

viewques(id):Observable<any>{
return this.hts.get(this.viewquesapi+'/'+id,{responseType:'json'})
}

viewtques(tid):Observable<any>{
  return this.hts.get(this.viewquesapi+'/t/'+tid,{responseType:'json'})
}

addtech(tech):Observable<any>{

  const headop={
    headers:new HttpHeaders({'Content-Type':'application/json'})
  }
  return this.hts.post(this.techapi,tech,headop)
}
addim(im):Observable<any>{
  const headop={
    headers:new HttpHeaders({'Content-Type':'application/json'})
  }
  return this.hts.post("http://localhost:4501/image",JSON.stringify(im),headop)
}

addques(qus):Observable<any>{
const htpop={
  headers:new HttpHeaders({'Content-Type':'application/json'})
}

return this.hts.post(this.quesapi,qus,htpop)
  }

}
