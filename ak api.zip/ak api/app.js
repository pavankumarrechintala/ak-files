var fs = require('fs');
var path = require('path');
var express = require('express');
var promise = require('bluebird');
var option = {
    promiseLib: promise
}
var bodyparser = require('body-parser');
var pgp = require('pg-promise')(option);
var cn = "postgres://postgres:root@localhost:5432/exam";
var db = pgp(cn);
var app = express();
app.set('port', process.env.PORT | 4501);

app.use(bodyparser.urlencoded({ extended: true, parameterLimit: 50000, limit: '50mb' }))
app.use(bodyparser.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'images')))
app.use(function (req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', '*');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'Cache-Control, Pragma, Origin, Authorization, Content-Type, X-Requested-With');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware

    next();
});
app.get('/', (req, res) => {
    res.send('welcome to online exam');
})
app.get('/tech', (req, res) => {
    db.any('select * from tech').then(data => { res.send(data) })
})
app.get('/ques/t/:tid', (req, res, next) => {
    var t = req.params.tid;
    db.any('select * from  questions where techid=$1', t).then(data => { res.send(data) })
})
app.get('/ques/:id', (req, res) => {
    var i = req.params.id;
    db.any('select * from questions where questionid=$1', i).then(data => { res.send(data) })
})

app.post('/tech', (req, res) => {
    console.log(req.body)
    c
    var tec = req.body.technology;
    db.any('insert into tech(technology) values($1)', [tec]).then(data => {
        res.send({ 'message': 'technology added' });
    })
})

app.post('/img', (req, res) => {
console.log('im');
console.log(req.body);
res.send('upload');
})
app.post('/image', (req, res) => {
    console.log(req.body.images)
    console.log('here')
    fn = 101 + '.wmv';
    cfn = path.join(__dirname, 'images/' + fn)
    fs.writeFile(cfn, req.body.images,'base64', err => {
        if (err) {
            console.log(err)
        }
        else {
            console.log('addedd');
        }
    })
})

app.post('/addques', (req, res) => {
    var q = req.body.question;
    var op1 = req.body.option1;
    var op2 = req.body.option2;
    var op3 = req.body.option3;
    var op4 = req.body.option4;
    var ans = req.body.answer;
    var tid = req.body.techid;
    db.any('insert into questions(question,option1,option2,option3,option4,answer,techid) values($1,$2,$3,$4,$5,$6,$7)',
        [q, op1, op2, op3, op4, ans, tid]).then(res.send({ 'message': 'inserted' }))
})

app.listen(app.get('port'), err => {
    if (err) {
        console.log('error')
    }
    else {
        console.log('server started at 4501')
    }
})



